Extract this ZIP, then open Thornwake-Play.html in Chrome or Edge. Do not open the HTML in the ChatGPT preview.
